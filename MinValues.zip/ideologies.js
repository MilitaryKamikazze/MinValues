ideologies = [
  {
    name: "NaN",
    stats: {
      econ: 0,
      dipl: 0,
      govt: 0,
      scty: 0
    }
  }
];
